Details about this assignment can be found [on the course webpage](https://compsci697l.github.io/assignments.html).
