Details about this assignment can be found [on the course webpage](https://compsci682.github.io/assignments.html).
